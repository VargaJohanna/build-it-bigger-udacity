package com.android.joker;

public class Joker {
    public static String getJoke() {
        return "Why is six afraid of seven? Because seven ate nine. :D";
    }
}
